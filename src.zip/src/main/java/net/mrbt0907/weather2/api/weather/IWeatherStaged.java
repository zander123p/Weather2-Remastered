package net.mrbt0907.weather2.api.weather;

public interface IWeatherStaged
{
	public int getStage();
	public void setStage(int stage);
}
