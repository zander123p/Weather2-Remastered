package net.mrbt0907.weather2.api.weather;

public interface IWeatherLayered
{
	public int getLayer();
	public int getLayerHeight();
}
