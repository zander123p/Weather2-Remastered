package net.mrbt0907.weather2.api.weather;

import net.mrbt0907.weather2.WeatherDebug.DebugInfo;

public abstract class AbstractDebugging
{
	public void getDebugInfo(DebugInfo info) {}
}
