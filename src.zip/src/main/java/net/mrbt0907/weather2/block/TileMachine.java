package net.mrbt0907.weather2.block;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;

public class TileMachine extends TileEntity implements ITickable
{
    @Override
    public void update()
    {
    	
    }
}
