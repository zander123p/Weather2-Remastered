package net.mrbt0907.weather2.registry;

public class GuiRegistry
{

}
