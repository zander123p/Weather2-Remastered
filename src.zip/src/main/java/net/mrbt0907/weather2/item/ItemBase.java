package net.mrbt0907.weather2.item;

import net.minecraft.item.Item;

public class ItemBase extends Item
{
	
}
