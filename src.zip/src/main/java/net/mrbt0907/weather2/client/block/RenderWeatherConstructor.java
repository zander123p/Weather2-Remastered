package net.mrbt0907.weather2.client.block;

import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntity;

public class RenderWeatherConstructor extends TileEntitySpecialRenderer<TileEntity>
{
    @Override
    public void render(TileEntity var1, double x, double y, double z, float var8, int destroyStage, float alpha) {
    	
    	
    }
}
